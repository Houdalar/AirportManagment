package com.example.tp1.entities;

public enum Specialite {
 IA,
 RESEAUX,
 CLOUD,
 SECURITE

}
