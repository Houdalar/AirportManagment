package com.example.tp1.entities;

public enum Niveau {
    JUNIOR,
    SENIOR,
    EXPERT,
}
