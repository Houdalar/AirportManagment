package com.example.tp1.entities;

public enum Option {
    GAMIX,
    SE,
    SIM,
    NIDS
}
